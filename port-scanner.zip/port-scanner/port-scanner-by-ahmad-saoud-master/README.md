# port-scanner-by-ahmad-saoud
Peace be upon you, this tool is a great tool that scans the open ports of Ip of your choice developed by ahmad soud "is me" in 
python3

#HI this tool for testing and security only


this tool start in python3 only

please read this comment

"for tool start correctly type in your terminal 'linux or termux'"

write in your terminal linux this comment:

apt-get update
 
apt install python3

apt install python3-pip

pip3 install V7xStyle

cd port-scanner-by-ahmad-saoud-master

python3 port scanner.py










In Windows Follow this step:

first download his tool zip


and unzip tools 


pip install V7xStyle or pip3 install V7wStyle


and run port scanner 
