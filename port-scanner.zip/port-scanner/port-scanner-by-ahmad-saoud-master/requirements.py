##########################################################
import os 
print ("Hi, Bro requirements begin install ...")
########################################################
os.system("apt-get update ")
print(" Your System  is uptaded ")
#########################################################
os.system("apt install python3")
print(" Python 3 Is Installed Now Wait For Install Pip3 ...")
os.system("apt install python3-pip")
#################################################################
print("Pip3 is Installed Now Wait For Library ....")
os.system("pip3 install V7xStyle")
print ("My Bro All Requirements is installed By ^-^ ")
#####################################################################
